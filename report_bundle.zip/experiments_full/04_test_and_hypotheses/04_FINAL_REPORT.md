# CAT vs DOG vs NOT — 전체 실험 최종 보고서 (04)

- 엔진 `cdn-full-2.1` sha256 `3b3495d8a3bb6ba7` · 사전 등록 `ed3bc1bf39e49d06` · E* = 60 · seeds [42, 43, 44, 45, 46]
- 확증 난이도 ['easy', 'mid', 'hard'] · H4~H10 난이도 hard · 선택 학습률 {'T': 0.0002, 'U': 0.0001}

## 1. 결론 (사전 등록 규칙에 따른 자동 판정)

### 연구 질문: 진단 기반 개선(T)과 일괄 확대(U)는 정말 다른 결과를 내는가?
- **EASY**: T−U 겨냥 방향군 +2.46 [+0.68, +4.23]/1,000 → H1 반대 방향 (지지 안 됨) · H2 해당 없음 (H1 미지지) · H3 실패 (오류 이동 있음)
- **MID**: T−U 겨냥 방향군 +4.94 [+0.37, +9.51]/1,000 → H1 반대 방향 (지지 안 됨) · H2 해당 없음 (H1 미지지) · H3 실패 (오류 이동 있음)
- **HARD**: T−U 겨냥 방향군 -18.62 [-25.98, -11.26]/1,000 → H1 지지됨 · H2 겨냥 방향 차이는 특이적, 대조 방향 동등은 미확립 · H3 통과 (지지됨)

### 다르다면, 그 차이는 무엇 때문인가? (HARD)
- **H4** 처방을 고정하고 백본만 EfficientNet-B0 로 바꿔도 겨냥 방향 오류가 준다 (EffB0 − R50 주효과, HARD) → -23.62 [-30.00, -17.23]/1,000 · p_holm 0.0000 · **지지됨 (실질적 크기)**
- **H5** 백본을 고정해도 진단 기반 처방이 일괄 처방보다 낫다 (T 처방 − U 처방 주효과, HARD) → +5.00 [+0.47, +9.53]/1,000 · p_holm 0.0974 · **지지 안 됨 (실질적 동등)**
- **H7** 혼합 짝을 진단된 쌍으로 제한하면 무작위 짝보다 낫다 (T − T_randpair, HARD) → +5.62 [-2.58, +13.82]/1,000 · p_holm 0.1503 · **지지 안 됨 (실질적 동등)**
- **H9** 혼합 배치에서 클래스 가중치를 끄면 not→cat 오류가 준다 (부작용: cat→not 가드) → -3.09 [-3.92, -2.27] %p · p_holm 0.0000 · **지지됨, 그러나 트레이드오프**
- **H10** 두 방법의 학습률을 각각 validation 으로 최적화한 뒤에도 T* < U* 가 유지된다 (HARD) → -6.90 [-14.35, +0.54]/1,000 · p_holm 0.1373 · **판단 불가**
- **H8** HARD 의 T < U 가 seed 를 바꿔도 유지된다 → -18.62 [-25.98, -11.26]/1,000 · p_holm 0.0000 · **지지됨**
- H6 (탐색) 상호작용 +3.05 [-4.73, +10.82]/1,000
- 분해: T − U = [백본 효과 (T 처방 고정)] -22.10 [-30.24, -13.95] + [처방 효과 (U 백본 고정)] +3.48 [-2.72, +9.67]
- **원인 요약**: 지지된 요인 = ['H4']. 백본(H4)만 지지되고 처방(H5)·쌍 한정(H7)은 지지되지 않으면 "차이의 원인은 백본" 입니다.

### 목적 ① 진단의 유용성
- EASY: D1 T−B -5.91 [-8.62, -3.21] (지지됨 (실질적 크기)), U−B -8.37 [-10.85, -5.89] (지지됨 (실질적 크기)) · D2 대조 방향 T−U 동등 False · D3 판정 기준 이동 test 이득 +0.0011 → 비율 문제 아님 True
- MID: D1 T−B +0.81 [-3.03, +4.65] (지지 안 됨 (실질적 동등)), U−B -4.13 [-8.79, +0.53] (판단 불가) · D2 대조 방향 T−U 동등 True · D3 판정 기준 이동 test 이득 -0.0011 → 비율 문제 아님 True
- HARD: D1 T−B -21.24 [-31.30, -11.18] (지지됨), U−B -2.62 [-9.90, +4.66] (지지 안 됨 (실질적 동등)) · D2 대조 방향 T−U 동등 False · D3 판정 기준 이동 test 이득 -0.0000 → 비율 문제 아님 True

### 목적 ② 공정한 비교 · ③ 원인 분리
- ② 는 위 H1·H2·H3·H8, ③ 은 H4·H5·H7·H9·H10 의 판정입니다. 모든 arm 은 같은 데이터 · 레시피 · epoch(E*) · seed · 배치 순서 · 난수 사건을 공유했고(03 학습 감사), test 는 한 번만 열렸습니다.

## 2. 가설 판정 요약

| hypothesis | scope | result |
|---|---|---|
| H1 | easy | 반대 방향 (지지 안 됨) |
| H2 | easy | 해당 없음 (H1 미지지) |
| H3 | easy | 실패 (오류 이동 있음) (G1 recall_cat (%p), G1 recall_dog (%p)) |
| H1 | mid | 반대 방향 (지지 안 됨) |
| H2 | mid | 해당 없음 (H1 미지지) |
| H3 | mid | 실패 (오류 이동 있음) (G1 recall_cat (%p), G1 recall_dog (%p), G1 recall_not (%p), G2 reverse family, G3 macro-F1) |
| H1 | hard | 지지됨 |
| H2 | hard | 겨냥 방향 차이는 특이적, 대조 방향 동등은 미확립 |
| H3 | hard | 통과 (지지됨) |
| H4 | hard | 지지됨 (실질적 크기) |
| H5 | hard | 지지 안 됨 (실질적 동등) |
| H6 | hard | 탐색 |
| H7 | hard | 지지 안 됨 (실질적 동등) |
| H8 | hard | 지지됨 |
| H10 | hard | 판단 불가 |
| H9 | hard | 지지됨, 그러나 트레이드오프 |

## 3. H1 · 대조 · DiD · 가드

| nt | name | estimate | ci95 | p | p_holm | margin | tost_equivalent | non_inferior | label |
|---|---|---|---|---|---|---|---|---|---|
| easy | H1 target family | 2.4571 | [+0.683, +4.231] | 0.0094 | 0.0188 | 1.6499 | False | False | 반대 방향 (지지 안 됨) |
| mid | H1 target family | 4.9362 | [+0.366, +9.506] | 0.0348 | 0.0348 | 5.6278 | False | False | 반대 방향 (지지 안 됨) |
| hard | H1 target family | -18.6191 | [-25.979, -11.260] | 0.0000 | 0.0000 | 12.8578 | False | True | 지지됨 |
| easy | control family (cat↔dog) | -1.7714 | [-4.248, +0.706] | 0.1579 | - | 2.0767 | False | True | - |
| mid | control family (cat↔dog) | -0.0851 | [-3.479, +3.309] | 0.9597 | - | 2.9844 | True | True | - |
| hard | control family (cat↔dog) | -2.8095 | [-6.835, +1.216] | 0.1677 | - | 2.6956 | False | True | - |
| easy | H2 DiD (target − control) | 4.2286 | [+1.293, +7.164] | 0.0053 | 0.0106 | - | - | - | 해당 없음 (H1 미지지) |
| mid | H2 DiD (target − control) | 5.0213 | [-0.094, +10.137] | 0.0544 | 0.0544 | - | - | - | 해당 없음 (H1 미지지) |
| hard | H2 DiD (target − control) | -15.8095 | [-24.879, -6.740] | 0.0009 | 0.0026 | - | - | - | 겨냥 방향 차이는 특이적, 대조 방향 동등은 미확립 |
| easy | G1 recall_cat (%p) | -0.2200 | [-2.133, +1.693] | 0.8091 | - | 1.0000 | False | False | - |
| easy | G1 recall_dog (%p) | -0.2600 | [-1.337, +0.817] | 0.6357 | - | 1.0000 | False | False | - |
| easy | G2 reverse family | -6.0571 | [-9.809, -2.305] | 0.0048 | - | 1.1463 | False | True | - |
| easy | G3 macro-F1 | 0.0077 | [-0.000, +0.016] | 0.0548 | - | 0.0100 | False | True | - |
| mid | G1 recall_cat (%p) | -0.9200 | [-2.370, +0.530] | 0.2115 | - | 1.0000 | False | False | - |
| mid | G1 recall_dog (%p) | -0.7000 | [-2.133, +0.733] | 0.3215 | - | 1.0000 | False | False | - |
| mid | G1 recall_not (%p) | -0.2741 | [-1.515, +0.967] | 0.6204 | - | 1.0000 | False | False | - |
| mid | G2 reverse family | 0.1702 | [-2.677, +3.018] | 0.8978 | - | 1.0090 | False | False | - |
| mid | G3 macro-F1 | -0.0055 | [-0.015, +0.004] | 0.2310 | - | 0.0100 | False | False | - |
| hard | G1 recall_cat (%p) | 3.5200 | [+1.754, +5.286] | 0.0001 | - | 1.0000 | False | True | - |
| hard | G1 recall_dog (%p) | 4.4800 | [+2.919, +6.041] | 0.0000 | - | 1.0000 | False | True | - |
| hard | G1 recall_not (%p) | 0.4545 | [-0.581, +1.490] | 0.3887 | - | 1.0000 | False | True | - |
| hard | G3 macro-F1 | 0.0238 | [+0.016, +0.032] | 0.0000 | - | 0.0100 | False | True | - |

### H1 방향별 (보조, Holm)

| nt | name | estimate | ci95 | p | p_holm | margin | tost_equivalent | non_inferior | label |
|---|---|---|---|---|---|---|---|---|---|
| easy | H1 cat->not (%p) | 1.0000 | [-0.094, +2.094] | 0.0702 | 0.2807 | 0.7975 | False | False | 판단 불가 |
| easy | H1 dog->not (%p) | 0.7200 | [+0.198, +1.242] | 0.0071 | 0.0499 | 0.5000 | False | False | 반대 방향 (지지 안 됨) |
| mid | H1 cat->not (%p) | 1.3600 | [+0.259, +2.461] | 0.0156 | 0.0936 | 1.1912 | False | False | 판단 불가 |
| mid | H1 dog->not (%p) | 0.3000 | [-0.627, +1.227] | 0.5139 | 1.0000 | 0.6306 | False | False | 판단 불가 |
| mid | H1 not->cat (%p) | 0.2444 | [-0.607, +1.096] | 0.5392 | 1.0000 | 0.5000 | False | False | 판단 불가 |
| hard | H1 cat->not (%p) | -3.6400 | [-5.225, -2.055] | 0.0000 | 0.0001 | 1.8252 | False | True | 지지됨 (실질적 크기) |
| hard | H1 dog->not (%p) | -3.1800 | [-4.637, -1.723] | 0.0001 | 0.0008 | 1.3847 | False | True | 지지됨 (실질적 크기) |
| hard | H1 not->cat (%p) | 0.3455 | [-0.495, +1.186] | 0.4190 | 1.0000 | 0.6381 | False | False | 판단 불가 |
| hard | H1 not->dog (%p) | -0.8000 | [-1.528, -0.072] | 0.0317 | 0.1583 | 0.5000 | False | True | 판단 불가 |

### McNemar (target family, seed 별, Holm)

| nt | seed | a_only_correct | b_only_correct | p | method | p_holm |
|---|---|---|---|---|---|---|
| easy | 42 | 25 | 31 | 0.5040 | chi2 cc | 1.0000 |
| easy | 43 | 12 | 38 | 0.0004 | chi2 cc | 0.0053 |
| easy | 44 | 12 | 33 | 0.0029 | chi2 cc | 0.0258 |
| easy | 45 | 12 | 36 | 0.0009 | chi2 cc | 0.0099 |
| easy | 46 | 26 | 35 | 0.3057 | chi2 cc | 1.0000 |
| mid | 42 | 113 | 119 | 0.7427 | chi2 cc | 1.0000 |
| mid | 43 | 111 | 147 | 0.0293 | chi2 cc | 0.2053 |
| mid | 44 | 111 | 127 | 0.3309 | chi2 cc | 1.0000 |
| mid | 45 | 103 | 137 | 0.0332 | chi2 cc | 0.2053 |
| mid | 46 | 109 | 133 | 0.1393 | chi2 cc | 0.6964 |
| hard | 42 | 276 | 201 | 0.0007 | chi2 cc | 0.0084 |
| hard | 43 | 288 | 200 | 0.0001 | chi2 cc | 0.0011 |
| hard | 44 | 272 | 206 | 0.0029 | chi2 cc | 0.0258 |
| hard | 45 | 289 | 194 | 0.0000 | chi2 cc | 0.0003 |
| hard | 46 | 269 | 202 | 0.0024 | chi2 cc | 0.0236 |

## 4. 원인 분리 (HARD)

| nt | name | estimate | ci95 | p | p_holm | margin | tost_equivalent | non_inferior | label |
|---|---|---|---|---|---|---|---|---|---|
| hard | H4 | -23.6190 | [-30.003, -17.235] | 0.0000 | 0.0000 | 12.8578 | False | True | 지지됨 (실질적 크기) |
| hard | H5 | 5.0000 | [+0.469, +9.531] | 0.0325 | 0.0974 | 12.8578 | True | True | 지지 안 됨 (실질적 동등) |
| hard | H6 | 3.0476 | [-4.730, +10.825] | 0.4296 | - | 12.8578 | True | True | 탐색 |
| hard | H5_at_resnet18 | 2.9524 | [-2.177, +8.082] | 0.2562 | - | 12.8578 | True | True | 탐색 |
| hard | H7 | 5.6190 | [-2.582, +13.820] | 0.1503 | 0.1503 | 12.8578 | True | True | 지지 안 됨 (실질적 동등) |
| hard | H8 | -18.6191 | [-25.979, -11.260] | 0.0000 | 0.0000 | 12.8578 | False | True | 지지됨 |
| hard | H10 | -6.9048 | [-14.351, +0.541] | 0.0687 | 0.1373 | 12.8578 | False | True | 판단 불가 |
| hard | decomp_backbone_at_Tpolicy | -22.0952 | [-30.241, -13.950] | 0.0000 | - | 12.8578 | False | True | 탐색 |
| hard | decomp_policy_at_Ubackbone | 3.4762 | [-2.720, +9.672] | 0.2585 | - | 12.8578 | True | True | 탐색 |
| hard | H9 | -3.0909 | [-3.916, -2.266] | 0.0000 | 0.0000 | 0.6381 | False | True | 지지됨, 그러나 트레이드오프 |
| hard | H9 guard cat→not (%p) | 6.5400 | [+5.457, +7.623] | 0.0000 | - | 1.8252 | False | False | 탐색 |

- H8 seed 별 T−U: [-17.86, -20.95, -15.71, -22.62, -15.95] · T 가 이긴 교차 쌍 25/25

## 5. 목적 ① 진단 예측 검증

| nt | name | estimate | ci95 | p | p_holm | margin | tost_equivalent | non_inferior | label |
|---|---|---|---|---|---|---|---|---|---|
| easy | D1 T − B target family | -5.9143 | [-8.618, -3.210] | 0.0006 | - | 1.6499 | False | True | 지지됨 (실질적 크기) |
| easy | D1 U − B target family | -8.3714 | [-10.849, -5.893] | 0.0000 | - | 1.6499 | False | True | 지지됨 (실질적 크기) |
| mid | D1 T − B target family | 0.8085 | [-3.032, +4.649] | 0.6769 | - | 5.6278 | True | True | 지지 안 됨 (실질적 동등) |
| mid | D1 U − B target family | -4.1277 | [-8.788, +0.533] | 0.0818 | - | 5.6278 | False | True | 판단 불가 |
| hard | D1 T − B target family | -21.2381 | [-31.300, -11.176] | 0.0003 | - | 12.8578 | False | True | 지지됨 |
| hard | D1 U − B target family | -2.6190 | [-9.899, +4.661] | 0.4725 | - | 12.8578 | True | True | 지지 안 됨 (실질적 동등) |

| nt | gain_mean | confirmed_not_ratio_problem |
|---|---|---|
| easy | 0.0011 | True |
| mid | -0.0011 | True |
| hard | -0.0000 | True |

## 6. 보조 지표 · 효율 · 확률 보정(ECE)

| nt | name | estimate | ci95 | p | p_holm | margin | tost_equivalent | non_inferior | label |
|---|---|---|---|---|---|---|---|---|---|
| easy | accuracy T−U | 0.0054 | [+0.001, +0.010] | 0.0303 | - | - | - | - | - |
| easy | macro_f1 T−U | 0.0077 | [-0.000, +0.016] | 0.0548 | - | - | - | - | - |
| mid | accuracy T−U | -0.0050 | [-0.013, +0.003] | 0.2099 | - | - | - | - | - |
| mid | macro_f1 T−U | -0.0055 | [-0.015, +0.004] | 0.2310 | - | - | - | - | - |
| hard | accuracy T−U | 0.0214 | [+0.014, +0.029] | 0.0000 | - | - | - | - | - |
| hard | macro_f1 T−U | 0.0238 | [+0.016, +0.032] | 0.0000 | - | - | - | - | - |

| nt | arm | backbone | policy | lr | params_M | gflops | train_gpu_min_mean | target_per1000_mean | macro_f1_mean | acc_mean | ece_mean |
|---|---|---|---|---|---|---|---|---|---|---|---|
| easy | B | resnet18 | B | 0.0002 | 11.3091 | 1.8100 | 30.2106 | 14.9714 | 0.9092 | 0.9501 | 0.1849 |
| easy | T | resnet18 | T | 0.0002 | 11.3091 | 1.8100 | 36.9808 | 9.0571 | 0.9093 | 0.9496 | 0.2329 |
| easy | U | resnet50 | U | 0.0002 | 24.0339 | 4.0900 | 100.9641 | 6.6000 | 0.9016 | 0.9442 | 0.1897 |
| mid | B | resnet18 | B | 0.0002 | 11.3091 | 1.8100 | 20.0681 | 52.9362 | 0.8881 | 0.9102 | 0.0817 |
| mid | T | resnet18 | T | 0.0002 | 11.3091 | 1.8100 | 24.5418 | 53.7447 | 0.8869 | 0.9073 | 0.1597 |
| mid | U | resnet50 | U | 0.0002 | 24.0339 | 4.0900 | 67.0582 | 48.8085 | 0.8923 | 0.9123 | 0.1045 |
| hard | B | resnet18 | B | 0.0002 | 11.3091 | 1.8100 | 18.4250 | 121.1429 | 0.8369 | 0.8525 | 0.0332 |
| hard | T | efficientnet_b0 | T | 0.0002 | 4.3368 | 0.3900 | 47.4952 | 99.9048 | 0.8665 | 0.8766 | 0.1665 |
| hard | U | resnet50 | U | 0.0002 | 24.0339 | 4.0900 | 57.1555 | 118.5238 | 0.8427 | 0.8551 | 0.0647 |
| hard | T@resnet18 | resnet18 | T | 0.0002 | 11.3091 | 1.8100 | 19.3869 | 124.8095 | 0.8309 | 0.8447 | 0.1171 |
| hard | U@resnet18 | resnet18 | U | 0.0002 | 11.3091 | 1.8100 | 20.0001 | 121.8572 | 0.8373 | 0.8506 | 0.0629 |
| hard | T@resnet50 | resnet50 | T | 0.0002 | 24.0339 | 4.0900 | 57.2908 | 122.0000 | 0.8386 | 0.8505 | 0.0753 |
| hard | U@efficientnet_b0 | efficientnet_b0 | U | 0.0002 | 4.3368 | 0.3900 | 44.6216 | 93.3810 | 0.8706 | 0.8818 | 0.1172 |
| hard | Trand | efficientnet_b0 | Trand | 0.0002 | 4.3368 | 0.3900 | 42.9007 | 94.2857 | 0.8693 | 0.8806 | 0.1126 |
| hard | Tunw | efficientnet_b0 | Tunw | 0.0002 | 4.3368 | 0.3900 | 42.1877 | 99.7619 | 0.8668 | 0.8798 | 0.1444 |
| hard | Ustar | resnet50 | U | 0.0001 | 24.0339 | 4.0900 | 55.6288 | 106.8095 | 0.8569 | 0.8689 | 0.0850 |

## 7. 통제 표 (실험 조작 이외 요인 고정 확인)

| nt | 구분 | 요인 | T | U | 같음 |
|---|---|---|---|---|---|
| easy | 고정 | 데이터 · 분할 (분할 지문) | 199e42e1b0ca6adb | 199e42e1b0ca6adb | True |
| easy | 고정 | train/val 이미지 수 | 27799 | 27799 | True |
| easy | 고정 | 클래스 가중치 (train 기준) | [2.319482686691698, 2.3212257849031395, 0.46771317046907596] | [2.319482686691698, 2.3212257849031395, 0.46771317046907596] | True |
| easy | 고정 | 분류 head 구조 | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | True |
| easy | 고정 | optimizer · weight decay | ('AdamW', 0.01) | ('AdamW', 0.01) | True |
| easy | 고정 | 학습률 (주 비교) | 0.0002 | 0.0002 | True |
| easy | 고정 | 배치 · warm-up · cosine · 최소 LR | (64, 3, 0.01) | (64, 3, 0.01) | True |
| easy | 고정 | 손실 · label smoothing · grad clip · AMP | ('class-weighted soft-target cross-entropy + label smoothing | ('class-weighted soft-target cross-entropy + label smoothing | True |
| easy | 고정 | 학습 예산 epoch (E*) · 조기 종료 | (60, None) | (60, None) | True |
| easy | 고정 | seed · 초기 head seed 규칙 | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | True |
| easy | 고정 | 배치 순서 · 기본 증강 난수 | stream(nt,seed,order/base,epoch,i) | stream(nt,seed,order/base,epoch,i) | True |
| easy | 고정 | 증강 난수 사건 스트림 | stream(nt,seed,event,epoch,step) | stream(nt,seed,event,epoch,step) | True |
| easy | 고정 | 평가 (마지막 epoch · 단일 뷰 · 같은 test) | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | True |
| easy | 조작 (T vs U 정의) | 백본 | resnet18 | resnet50 | False |
| easy | 조작 (T vs U 정의) | Random Erasing p | 0.5 | 0.25 | False |
| easy | 조작 (T vs U 정의) | RandAugment | False | True | False |
| easy | 조작 (T vs U 정의) | CutMix/MixUp | ['cutmix'] | ['cutmix', 'mixup'] | False |
| easy | 조작 (T vs U 정의) | 혼합 짝 | targeted | random | False |
| easy | 조작 (T vs U 정의) | EMA | True | True | True |
| mid | 고정 | 데이터 · 분할 (분할 지문) | 199e42e1b0ca6adb | 199e42e1b0ca6adb | True |
| mid | 고정 | train/val 이미지 수 | 18764 | 18764 | True |
| mid | 고정 | 클래스 가중치 (train 기준) | [1.5652318985652318, 1.5660156902019695, 0.5805333828352206] | [1.5652318985652318, 1.5660156902019695, 0.5805333828352206] | True |
| mid | 고정 | 분류 head 구조 | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | True |
| mid | 고정 | optimizer · weight decay | ('AdamW', 0.01) | ('AdamW', 0.01) | True |
| mid | 고정 | 학습률 (주 비교) | 0.0002 | 0.0002 | True |
| mid | 고정 | 배치 · warm-up · cosine · 최소 LR | (64, 3, 0.01) | (64, 3, 0.01) | True |
| mid | 고정 | 손실 · label smoothing · grad clip · AMP | ('class-weighted soft-target cross-entropy + label smoothing | ('class-weighted soft-target cross-entropy + label smoothing | True |
| mid | 고정 | 학습 예산 epoch (E*) · 조기 종료 | (60, None) | (60, None) | True |
| mid | 고정 | seed · 초기 head seed 규칙 | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | True |
| mid | 고정 | 배치 순서 · 기본 증강 난수 | stream(nt,seed,order/base,epoch,i) | stream(nt,seed,order/base,epoch,i) | True |
| mid | 고정 | 증강 난수 사건 스트림 | stream(nt,seed,event,epoch,step) | stream(nt,seed,event,epoch,step) | True |
| mid | 고정 | 평가 (마지막 epoch · 단일 뷰 · 같은 test) | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | True |
| mid | 조작 (T vs U 정의) | 백본 | resnet18 | resnet50 | False |
| mid | 조작 (T vs U 정의) | Random Erasing p | 0.5 | 0.25 | False |
| mid | 조작 (T vs U 정의) | RandAugment | False | True | False |
| mid | 조작 (T vs U 정의) | CutMix/MixUp | ['cutmix', 'mixup'] | ['cutmix', 'mixup'] | True |
| mid | 조작 (T vs U 정의) | 혼합 짝 | targeted | random | False |
| mid | 조작 (T vs U 정의) | EMA | True | True | True |
| hard | 고정 | 데이터 · 분할 (분할 지문) | 199e42e1b0ca6adb | 199e42e1b0ca6adb | True |
| hard | 고정 | train/val 이미지 수 | 16767 | 16767 | True |
| hard | 고정 | 클래스 가중치 (train 기준) | [1.3986486486486487, 1.399349023535303, 0.6367779423493221] | [1.3986486486486487, 1.399349023535303, 0.6367779423493221] | True |
| hard | 고정 | 분류 head 구조 | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | {'hidden': 256, 'batchnorm': True, 'act': 'relu', 'dropout': | True |
| hard | 고정 | optimizer · weight decay | ('AdamW', 0.01) | ('AdamW', 0.01) | True |
| hard | 고정 | 학습률 (주 비교) | 0.0002 | 0.0002 | True |
| hard | 고정 | 배치 · warm-up · cosine · 최소 LR | (64, 3, 0.01) | (64, 3, 0.01) | True |
| hard | 고정 | 손실 · label smoothing · grad clip · AMP | ('class-weighted soft-target cross-entropy + label smoothing | ('class-weighted soft-target cross-entropy + label smoothing | True |
| hard | 고정 | 학습 예산 epoch (E*) · 조기 종료 | (60, None) | (60, None) | True |
| hard | 고정 | seed · 초기 head seed 규칙 | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | ([42, 43, 44, 45, 46], 'stream(nt,seed,init)') | True |
| hard | 고정 | 배치 순서 · 기본 증강 난수 | stream(nt,seed,order/base,epoch,i) | stream(nt,seed,order/base,epoch,i) | True |
| hard | 고정 | 증강 난수 사건 스트림 | stream(nt,seed,event,epoch,step) | stream(nt,seed,event,epoch,step) | True |
| hard | 고정 | 평가 (마지막 epoch · 단일 뷰 · 같은 test) | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | final epoch (EMA 가 있는 arm 은 EMA, 없으면 원 가중치) — validation 으로  | True |
| hard | 조작 (T vs U 정의) | 백본 | efficientnet_b0 | resnet50 | False |
| hard | 조작 (T vs U 정의) | Random Erasing p | 0.5 | 0.25 | False |
| hard | 조작 (T vs U 정의) | RandAugment | False | True | False |
| hard | 조작 (T vs U 정의) | CutMix/MixUp | ['cutmix', 'mixup'] | ['cutmix', 'mixup'] | True |
| hard | 조작 (T vs U 정의) | 혼합 짝 | targeted | random | False |
| hard | 조작 (T vs U 정의) | EMA | True | True | True |

## 8. 수렴 점검 (보고 전용 — 마지막 20% epoch 의 validation 변화)

| nt | seed | arm | tail_epochs | lr_at_tail_start | target_per1000_change | macro_f1_change | still_improving |
|---|---|---|---|---|---|---|---|
| easy | 42 | B | 12 | 0.0000 | 1.5827 | 0.0070 | False |
| easy | 42 | T | 12 | 0.0000 | 0.1439 | 0.0021 | False |
| easy | 42 | U | 12 | 0.0000 | 1.0072 | -0.0008 | False |
| easy | 43 | B | 12 | 0.0000 | -1.5827 | 0.0046 | True |
| easy | 43 | T | 12 | 0.0000 | 0.4317 | -0.0015 | False |
| easy | 43 | U | 12 | 0.0000 | 0.4317 | 0.0021 | False |
| easy | 44 | B | 12 | 0.0000 | -3.0216 | 0.0028 | True |
| easy | 44 | T | 12 | 0.0000 | 1.2950 | 0.0032 | False |
| easy | 44 | U | 12 | 0.0000 | 0.0000 | 0.0001 | False |
| easy | 45 | B | 12 | 0.0000 | 1.2950 | 0.0007 | False |
| easy | 45 | T | 12 | 0.0000 | 0.5755 | -0.0029 | False |
| easy | 45 | U | 12 | 0.0000 | 1.0072 | 0.0007 | False |
| easy | 46 | B | 12 | 0.0000 | -0.4317 | 0.0021 | False |
| easy | 46 | T | 12 | 0.0000 | 1.0072 | 0.0026 | False |
| easy | 46 | U | 12 | 0.0000 | 0.0000 | -0.0010 | False |
| mid | 42 | B | 12 | 0.0000 | -6.6084 | 0.0057 | True |
| mid | 42 | T | 12 | 0.0000 | 2.7713 | -0.0031 | False |
| mid | 42 | U | 12 | 0.0000 | -2.7713 | 0.0030 | False |
| mid | 43 | B | 12 | 0.0000 | 1.0659 | 0.0024 | False |
| mid | 43 | T | 12 | 0.0000 | -0.6395 | 0.0017 | False |
| mid | 43 | U | 12 | 0.0000 | -3.4108 | 0.0047 | True |
| mid | 44 | B | 12 | 0.0000 | 0.4263 | 0.0004 | False |
| mid | 44 | T | 12 | 0.0000 | 4.0503 | -0.0053 | False |
| mid | 44 | U | 12 | 0.0000 | 2.9844 | -0.0012 | False |
| mid | 45 | B | 12 | 0.0000 | 0.0000 | 0.0017 | False |
| mid | 45 | T | 12 | 0.0000 | -0.2132 | 0.0023 | False |
| mid | 45 | U | 12 | 0.0000 | -1.2790 | 0.0012 | False |
| mid | 46 | B | 12 | 0.0000 | -4.4767 | 0.0032 | True |
| mid | 46 | T | 12 | 0.0000 | 1.4922 | 0.0016 | False |
| mid | 46 | U | 12 | 0.0000 | -1.0659 | 0.0025 | False |
| hard | 42 | B | 12 | 0.0000 | -1.6698 | 0.0030 | False |
| hard | 42 | T | 12 | 0.0000 | 0.4771 | -0.0008 | False |
| hard | 42 | U | 12 | 0.0000 | 0.9542 | 0.0010 | False |
| hard | 42 | T@resnet18 | 12 | 0.0000 | 3.5782 | -0.0050 | False |
| hard | 42 | U@resnet18 | 12 | 0.0000 | 1.4313 | -0.0006 | False |
| hard | 42 | T@resnet50 | 12 | 0.0000 | 4.0553 | -0.0047 | False |
| hard | 42 | U@efficientnet_b0 | 12 | 0.0000 | -0.2385 | 0.0009 | False |
| hard | 42 | Trand | 12 | 0.0000 | -0.2385 | 0.0016 | False |
| hard | 42 | Tunw | 12 | 0.0000 | 0.2385 | -0.0001 | False |
| hard | 42 | Ustar | 12 | 0.0000 | 0.2385 | -0.0027 | False |
| hard | 43 | B | 12 | 0.0000 | -4.0553 | 0.0035 | False |
| hard | 43 | T | 12 | 0.0000 | -1.1927 | 0.0011 | False |
| hard | 43 | U | 12 | 0.0000 | 7.3950 | -0.0056 | False |
| hard | 43 | T@resnet18 | 12 | 0.0000 | -0.7156 | 0.0006 | False |
| hard | 43 | U@resnet18 | 12 | 0.0000 | -2.8626 | 0.0059 | False |
| hard | 43 | T@resnet50 | 12 | 0.0000 | 2.6240 | -0.0032 | False |
| hard | 43 | U@efficientnet_b0 | 12 | 0.0000 | -1.1927 | 0.0026 | False |
| hard | 43 | Trand | 12 | 0.0000 | 0.4771 | -0.0013 | False |
| hard | 43 | Tunw | 12 | 0.0000 | 0.9542 | 0.0006 | False |
| hard | 43 | Ustar | 12 | 0.0000 | -0.2385 | -0.0023 | False |
| hard | 44 | B | 12 | 0.0000 | 3.8168 | -0.0021 | False |
| hard | 44 | T | 12 | 0.0000 | -1.6698 | 0.0012 | False |
| hard | 44 | U | 12 | 0.0000 | 4.5324 | -0.0039 | False |
| hard | 44 | T@resnet18 | 12 | 0.0000 | -2.6240 | 0.0038 | False |
| hard | 44 | U@resnet18 | 12 | 0.0000 | 3.1011 | -0.0004 | False |
| hard | 44 | T@resnet50 | 12 | 0.0000 | 2.3855 | -0.0035 | False |
| hard | 44 | U@efficientnet_b0 | 12 | 0.0000 | 0.2385 | 0.0009 | False |
| hard | 44 | Trand | 12 | 0.0000 | -0.9542 | 0.0010 | False |
| hard | 44 | Tunw | 12 | 0.0000 | 0.2385 | -0.0010 | False |
| hard | 44 | Ustar | 12 | 0.0000 | -0.7156 | -0.0006 | False |
| hard | 45 | B | 12 | 0.0000 | -1.6698 | 0.0038 | False |
| hard | 45 | T | 12 | 0.0000 | -4.0553 | 0.0031 | False |
| hard | 45 | U | 12 | 0.0000 | -3.8168 | 0.0027 | False |
| hard | 45 | T@resnet18 | 12 | 0.0000 | 2.1469 | -0.0047 | False |
| hard | 45 | U@resnet18 | 12 | 0.0000 | 2.3855 | -0.0028 | False |
| hard | 45 | T@resnet50 | 12 | 0.0000 | -1.4313 | 0.0004 | False |
| hard | 45 | U@efficientnet_b0 | 12 | 0.0000 | 1.4313 | -0.0017 | False |
| hard | 45 | Trand | 12 | 0.0000 | -0.7156 | -0.0007 | False |
| hard | 45 | Tunw | 12 | 0.0000 | 1.1927 | -0.0014 | False |
| hard | 45 | Ustar | 12 | 0.0000 | 1.9084 | -0.0036 | False |
| hard | 46 | B | 12 | 0.0000 | 4.5324 | -0.0042 | False |
| hard | 46 | T | 12 | 0.0000 | 0.0000 | -0.0014 | False |
| hard | 46 | U | 12 | 0.0000 | 2.3855 | -0.0073 | False |
| hard | 46 | T@resnet18 | 12 | 0.0000 | -0.7156 | 0.0008 | False |
| hard | 46 | U@resnet18 | 12 | 0.0000 | -1.4313 | 0.0003 | False |
| hard | 46 | T@resnet50 | 12 | 0.0000 | 1.9084 | -0.0026 | False |
| hard | 46 | U@efficientnet_b0 | 12 | 0.0000 | -1.4313 | 0.0024 | False |
| hard | 46 | Trand | 12 | 0.0000 | 1.4313 | -0.0019 | False |
| hard | 46 | Tunw | 12 | 0.0000 | 1.9084 | -0.0020 | False |
| hard | 46 | Ustar | 12 | 0.0000 | 0.7156 | -0.0022 | False |

## 9. 기존 보고서 수치 (참고 — 판정에 쓰지 않음)

| item | legacy |
|---|---|
| T_minus_U_hard | -25.0 [-34.8, -15.0] |
| T_minus_U_easy | -0.9 [-3.0, +1.3] |
| T_minus_U_mid | -0.9 [-7.0, +5.3] |
| H4 | -23.8 [-31.3, -15.8] |
| H5 | -1.2 [-7.6, +4.8] |
| H6 | -3.3 [-16.2, +9.0] |
| H7 | -0.5 [-8.3, +7.4] |
| H8 | -18.3 [-28.4, -8.1] |
| H9_pp | -2.2 [-3.0, -1.4] |
| H10 | -16.4 [-26.0, -7.1] |

## 10. 설계와 한계

- 모든 arm 은 같은 데이터 분할 · 레시피 · epoch(E*) · 조기 종료 없음 · 마지막 가중치 평가 · 같은 seed · 같은 배치 순서와 난수 사건을 공유했습니다.
- T 와 U 는 정의상 백본 · 증강 묶음이 다릅니다(원래 연구 질문). 그 차이의 원인은 요인 설계(H4·H5·H6)와 절제(H7·H9)·학습률(H10)로 분리했습니다.
- epoch 보정 포화 확인: True. 보정·학습률 선택은 별도 seed 의 validation 으로만 했습니다.
- 확증 run 수렴 점검: 마지막 20% epoch 에도 허용오차 넘게 개선 중이던 run·arm 5/80 (0 이 아니면 해당 arm 은 학습 예산이 부족했을 수 있음).
- H10: 각자 선택된 학습률로 별도 학습한 T*·U* 를 비교했습니다.
- 학습 예산은 epoch · optimizer step · 본 이미지 수로 같게 맞췄습니다. 연산량(GFLOPs)은 처방 정의상 다르며 효율 표에 보고합니다.
- test 세트는 기존 프로젝트에서 열린 적이 있습니다(완전한 맹검 아님). 새 test 세트로 재확인하면 이 한계가 해소됩니다.
- seed 5개: hybrid 구간은 seed 간 변동이 크면 약간 낙관적일 수 있습니다.
- p > 0.05 는 동등의 근거가 아니며(동등은 TOST), 특이성은 DiD 로만 판단했습니다.

## 11. 그림

![](figures/forest_all.png)
![](figures/directions_easy.png)
![](figures/directions_mid.png)
![](figures/directions_hard.png)
![](figures/factorial.png)