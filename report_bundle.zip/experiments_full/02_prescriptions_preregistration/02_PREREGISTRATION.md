# 사전 등록 (02)

- 사전 등록 sha256: `ed3bc1bf39e49d06aacdc22a75804a78fb34af74362f72910b0bedf3560eca24`
- E* = 60 · seeds [42, 43, 44, 45, 46] · 학습률 {'T': 0.0002, 'U': 0.0001}
- 확증 난이도 ['easy', 'mid', 'hard'] · H4~H10 난이도 hard (검정 가능: True)

## 가설
- **H1** T 는 자신이 겨냥한 오류 방향(군)에서 U 보다 덜 틀린다 (난이도별)
- **H2** 그 차이는 겨냥 방향에서만 나타나고 대조 방향(cat↔dog)에서는 나타나지 않는다 (DiD)
- **H3** T 의 개선은 다른 곳을 망쳐서 얻은 것이 아니다 (원래 클래스 재현율 · 역방향 오류 · macro-F1 비열등)
- **H4** 처방을 고정하고 백본만 EfficientNet-B0 로 바꿔도 겨냥 방향 오류가 준다 (EffB0 − R50 주효과, HARD)
- **H5** 백본을 고정해도 진단 기반 처방이 일괄 처방보다 낫다 (T 처방 − U 처방 주효과, HARD)
- **H6** 처방 효과가 백본에 따라 달라진다 (상호작용, 탐색)
- **H7** 혼합 짝을 진단된 쌍으로 제한하면 무작위 짝보다 낫다 (T − T_randpair, HARD)
- **H8** HARD 의 T < U 가 seed 를 바꿔도 유지된다
- **H9** 혼합 배치에서 클래스 가중치를 끄면 not→cat 오류가 준다 (부작용: cat→not 가드)
- **H10** 두 방법의 학습률을 각각 validation 으로 최적화한 뒤에도 T* < U* 가 유지된다 (HARD)

## 목적
- **P1** ① 진단의 유용성 — 진단이 지목한 경계는 개선 가능하고(D1), 대조 경계는 두 처방이 같으며(D2), 판정 기준 이동으로는 풀리지 않는다(D3)
- **P2** ② 공정한 비교 — 같은 조건에서 T 와 U 가 겨냥 방향에서만 다른가 (H1·H2·H3·H8)
- **P3** ③ 원인 분리 — 차이가 처방·백본·쌍 한정·클래스 가중치·학습률 중 무엇 때문인가 (H4~H7·H9·H10)

## arm
- EASY: B(resnet18, B, lr 0.0002), T(resnet18, T, lr 0.0002), U(resnet50, U, lr 0.0002)
- MID: B(resnet18, B, lr 0.0002), T(resnet18, T, lr 0.0002), U(resnet50, U, lr 0.0002)
- HARD: B(resnet18, B, lr 0.0002), T(efficientnet_b0, T, lr 0.0002), U(resnet50, U, lr 0.0002), T@resnet18(resnet18, T, lr 0.0002), U@resnet18(resnet18, U, lr 0.0002), T@resnet50(resnet50, T, lr 0.0002), U@efficientnet_b0(efficientnet_b0, U, lr 0.0002), Trand(efficientnet_b0, Trand, lr 0.0002), Tunw(efficientnet_b0, Tunw, lr 0.0002), Ustar(resnet50, U, lr 0.0001)

## 대비 (FOCUS)
- H4: {'T': 0.5, 'U@efficientnet_b0': 0.5, 'T@resnet50': -0.5, 'U': -0.5}
- H5: {'T': 0.5, 'T@resnet50': 0.5, 'U@efficientnet_b0': -0.5, 'U': -0.5}
- H6: {'T': 1, 'U@efficientnet_b0': -1, 'T@resnet50': -1, 'U': 1}
- H5_at_resnet18: {'T@resnet18': 1, 'U@resnet18': -1}
- H7: {'T': 1, 'Trand': -1}
- H8: {'T': 1, 'U': -1}
- H9: {'Tunw': 1, 'T': -1}
- H10: {'T': 1, 'Ustar': -1}
- decomp_backbone_at_Tpolicy: {'T': 1, 'T@resnet50': -1}
- decomp_policy_at_Ubackbone: {'T@resnet50': 1, 'U': -1}